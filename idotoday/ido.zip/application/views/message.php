<?php

echo $this->session->flashdata('msg');

?>