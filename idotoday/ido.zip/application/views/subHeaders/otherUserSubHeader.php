<nav>

<a href='<?php echo base_url(); ?>index.php/user/workstatus/person'>WorkStatus</a>
<a href='<?php echo base_url(); ?>index.php/user/professions/person'>Professions</a>
<a href='<?php echo base_url(); ?>index.php/user/about/person'>About</a>
<a href='<?php echo base_url(); ?>index.php/user/reviews/person'>Reviews</a>
<a href='<?php echo base_url(); ?>index.php/user/connections/person'>Connections</a>
</nav>