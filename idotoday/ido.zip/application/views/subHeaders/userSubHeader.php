<nav>
<a href='<?php echo base_url(); ?>index.php/user/workstatus'>WorkStatus</a>
<a href='<?php echo base_url(); ?>index.php/user/professions'>Professions</a>
<a href='<?php echo base_url(); ?>index.php/user/requests'>Requests</a>
<a href='<?php echo base_url(); ?>index.php/user/about'>About</a>
<a href='<?php echo base_url(); ?>index.php/user/reviews'>Work&amp;Reviews</a>
<a href='<?php echo base_url(); ?>index.php/user/connections'>Connections</a>
</nav>