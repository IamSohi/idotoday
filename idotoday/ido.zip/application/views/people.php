<main>

<?php echo validation_errors(); ?>
<?php echo form_open('user/workstatus/updatestatus'); ?>
<input type='search' name='searchPeople'>
<input type="submit" name='search' value='Search'>

</form>

<h2>People</h2>

<?php foreach($people as $item):?>



<img src='<?php echo base_url();?>uploads/defaultprofilepic.jpg' id='preview' height='42' width='42'>
<a href='<?php echo base_url();?>index.php/people/person/<?php echo $item['user_id'];?>'><h3> <?php echo $item['user_id'];?> </h3></a>
<h1 class='hh'></h1>
<!--<a href='<?php echo base_url();?>index.php/people/connect/<?php echo $item['user_id'];?>'>
<button type='button' name='connect' value='Connect' class='connect' onclick="connect('<?php echo base_url();?>')">Connect</button></a>-->

<button type='button' id='connect<?php echo $item["user_id"];?>' name='connect' value='Connect' class='connect' onclick='connect(<?php echo $item["user_id"];?>)'>Connect</button>
<button type='button' id='unconnect<?php echo $item["user_id"];?>' name='unconnect' value='unConnect' class='unconnect' onclick='unConnect(<?php echo $item["user_id"];?>)'hidden>Un Connect</button>

<br/>

   
<?php endforeach;?>

<!--<h2>Professionals</h3>-->
<!--<h2>People With same Interest</h2>-->



</main>

