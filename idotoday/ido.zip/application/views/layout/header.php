<?php

?>

<!DOCTYPE html>
<html lang="en-US">
<head>

<title>

</title>

<link rel="stylesheet" type="text/css" href="css/loginstyle.css">
<meta charset="UTF-8">
<meta name="description" content="Welcome Page">
<meta name="keywords" content="Work,Employment,Jobs,People">
<meta name="author" content="Sukhveer Sohi">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jquerymobile/1.4.5/jquery.mobile.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquerymobile/1.4.5/jquery.mobile.min.js"></script>

<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>


<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/3.51/jquery.form.js"></script> 


<script type="text/javascript" src="<?php echo base_url();?>assets/js/idoScript.js"></script> 


</head>
<body>

