<br>
<a href='<?php echo base_url(); ?>index.php/frontend/footercontroller/options/about'>About</a>
<a href='<?php echo base_url(); ?>index.php/frontend/footercontroller/options/contact'>Contact</a>
<a href='<?php echo base_url(); ?>index.php/frontend/footercontroller/options/faq'>FAQ</a>
<a href='<?php echo base_url(); ?>index.php/frontend/footercontroller/options/terms'>terms</a>
<a href='<?php echo base_url(); ?>index.php/frontend/footercontroller/options/privacy'>privacy</a>
<br>
<h5>Sohi Production</h5>
<h5>&copy; idonow <?php echo date("Y");?></h5>
</body>
</html>