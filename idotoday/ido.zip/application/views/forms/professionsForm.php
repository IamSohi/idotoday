

<h2>What's your best part?</h2>
<?php echo validation_errors(); ?>
<?php echo form_open('user/professions/add'); ?>

<input type='text' name='profession' placeholder='profession'><br/>
<textarea name='description' placeholder='Description'  rows="4" cols="50"></textarea><span>(Optional)</span><br/>
<input type='text' name='workplace' placeholder='Place of Work'><br/>

<input type='text' name='price' list="price" placeholder='Amount Charged'>
  <datalist id="price">
    <option value="depends on requirements">
  </datalist>

<select name='currency'>
  <option value="inr">Inr</option>
  <option value="dollar">$</option>
</select>
<span>per</span>
<select name='timescale'>
  <option value="hour">hour</option>
  <option value="work">Work</option>
</select>
<br/>
<input type='submit' name='submit' value='Submit'>






</form>
