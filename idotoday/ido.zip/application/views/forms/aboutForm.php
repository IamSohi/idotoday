<h1>About Me</h1>

<?php echo validation_errors(); ?>
<?php echo form_open('user/about/edit'); ?>





<h3>My Passion</h3><input type='text' name='passion' value='<?php if(isset($passion))echo $passion; ?>' required>
<h3>MY Purpose</h3><input type='text' name='purpose' value='<?php if(isset($purpose))echo $purpose; ?>' required >
<h3>My Lifegoals</h3><input type='text' name='lifegoals' value='<?php if(isset($lifegoals))echo $lifegoals; ?>' >
<h3>Date of Birth</h3><input type='date' name='dob' value='<?php if(isset($dob))echo $dob; ?>' >
<h3>country Code</h3><input type='number' name='country_code' maxlength='5' value='<?php  if(isset($country_code))echo $country_code; ?>' >
<h3>Phone Number</h3><input type='number' name='number'maxlength='12' value='<?php if(isset($phone_number))echo $phone_number; ?>' >
<h3>City</h3><input type='text' name='city' value='<?php if(isset($city))echo $city; ?>' >


<h3>Do yo love what you do?</h3>
<input type='radio' name='loveYourWork' value='true' id='loveYourWork' required  checked>I do
<input type='radio' name='loveYourWork' value='false' required>I donot


<h3>Do you believe what you do?</h3>
<input type='radio' name='beleive'  id='believe' value='true' required checked>I do
<input type='radio' name='beleive' value='false' required>I donot

<br/>

<input type='submit' name='submit' value='Submit'>

</form>


<script>
if(<?php echo $believeWork; ?>==1){

    document.getElementById('believe').checked=true;
}
if(<?php echo $loveWork; ?>==1){

    document.getElementById('loveYourWork').checked=true;
}



</script>