<h2>Login</h2>
<?php echo validation_errors(); ?>
<?php echo form_open('regist/login/logitin'); ?>

<input type='email' name='email' placeholder='Email' value='<?php if(isset($email)){echo $email;}?>'>
<input type='password' name='pwd' placeholder='Password'>
<input type='submit' value='Login'>

</form>