

<h2>Ask for help</h2>
<?php echo validation_errors(); ?>
<?php echo form_open('user/requests/request'); ?>

<input type='text' name='request' placeholder='Request' required><br/>
<textarea name='description' placeholder='Description'  rows="4" cols="50"></textarea><span>(Optional)</span><br/>

<span>To Whom</span>
<select name='toWhom' required>
  <option value="all around you">all around you</option>
  <option value="only professionals">only professionals</option>
  <option value="anyone on the network">anyone on the network</option>
  <option value="with same work Status">with same work Status</option>
  <option value="with same profession">with same profession</option>
</select><br/>

<input type='text' name='bounty' list="bounty" placeholder='Bounty Or Reward'>
  <datalist id="bounty">
    <option value="depends on requirements">
  </datalist>

<select name='currency'>
  <option value="inr">Inr</option>
  <option value="dollar">$</option>
</select><span>(Optional)</span><br/>

<input type='submit' name='submit' value='Request'>




</form>