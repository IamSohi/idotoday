

<h2>Share What You Do</h2>
<?php echo validation_errors(); ?>
<?php echo form_open('user/workstatus/updatestatus'); ?>

<input type='text' name='status' placeholder='Work Status'><br/>
<textarea name='description' placeholder='Description'  rows="4" cols="50"></textarea><span>(Optional)</span><br/>
<input type='text' name='place' placeholder='Place of Work'><br/>
<select name='feeling'>
  <option value="Love-it">Love-it</option>
  <option value="Happy">Happy</option>
  <option value="Free">Free</option>
  <option value="Busy">Busy</option>
</select>
<br/>
<input type='submit' name='submit' value='Update'>


</form>
