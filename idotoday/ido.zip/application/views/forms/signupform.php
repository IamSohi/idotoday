<?php


?>

<h2>CREATE AN ACCOUNT</h2>

<?php echo validation_errors(); ?>
<?php echo form_open('regist/signup/signitup'); ?>
<input type='text' name='firstname' placeholder='firstName' value='<?php echo set_value('firstname'); ?>' required>
<input type='text' name='lastname' placeholder='lastName' value='<?php echo set_value('lastname'); ?>' required><br/>
<input type='email' name='email' placeholder='eamil or phone' value='<?php echo set_value('email'); ?>' required><br/>
<input type='password' name='pwd' placeholder='password' required><br/>
<input type='radio' name='gender' value='male' required> Male
<input type='radio' name='gender' value='female' required> Female
<input type='radio'  name='gender' value='other' required> Other<br/>

<input type='submit' name='submit' value='SignUp'>

</form>