<header>
<img src="<?php echo base_url();?>assets/images/didoIcon.png" alt="siteLogo">
<span>IDONOW</span>
<button><a href='<?php echo base_url(); ?>index.php/regist/login'>Login</a></button>
</header>