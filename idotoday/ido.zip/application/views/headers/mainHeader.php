<header>
<nav>
<a href='<?php echo base_url(); ?>index.php/user/profile'>
<img src="<?php echo base_url();?>assets/images/didoIcon.png" alt="siteLogo">
<span>IDONOW</span></a>

<a href='<?php echo base_url(); ?>index.php/user/workstatus'>Me</a>
<a href='<?php echo base_url(); ?>index.php/work'>Work</a>
<a href='<?php echo base_url(); ?>index.php/people'>People</a>
<a href='<?php echo base_url(); ?>index.php/requests'>Requests</a>
<button>N</button>
<button>O</button>
</nav>
</header>