<main>

<h2>Request Around You</h2>

<?php foreach($request as $item):?>



   
<?php endforeach;?>
<h2>Rewarded Requests</h3>
<?php foreach($request as $item):?>



   
<?php endforeach;?>


<h2>Requests by topic</h2>
<?php foreach($request as $item):?>



   
<?php endforeach;?>


</main>