<main>
<?php echo validation_errors(); ?>
<?php echo form_open('user/workstatus/updatestatus'); ?>
<input type='search' name='searchWork'>
<input type="submit" name='search' value='Search'>

</form>

<h2>WorkStatus</h2>

<?php foreach($workStatus as $item):?>



   
<?php endforeach;?>
<h2>Work</h3>
<?php foreach($work as $item):?>



   
<?php endforeach;?>


<h2>Professional Work</h2>
<?php foreach($professionalWork as $item):?>



   
<?php endforeach;?>



</main>

