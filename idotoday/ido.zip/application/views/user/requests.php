<main>
<?php

   foreach($result as $item):?>
<h2>Request : <?php if(isset($item['request']))echo $item['request'];?></h2>
<h2>Description : <?php if(isset($item['description'])){echo $item['description'];}else{echo 'No';}?></h2>
<h2>To : <?php if(isset($item['to_who'])){echo $item['to_who'];}?></h2>
<h2>Reward : <?php if(isset($item['bounty'])){echo $item['bounty'].' ';if(isset($item['currency']))echo $item['currency'];}else{echo 'No';}?></h2>
<h2>Accepted By : <?php if(isset($accepted_by)){echo $accepted_by;}else{echo 'Not yet Accepted';}?></h2>



   <br/>
   <br/>
   <br/>
   


<?php endforeach;?>

</main>