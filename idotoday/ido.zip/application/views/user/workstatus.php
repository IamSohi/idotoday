<main>

<h2>Work Status : <?php if(isset($workStatus))echo $workStatus; ?></h2>
<p>Description : <?php if(isset($description))echo $description; ?></p>
<h4>Place Of Work : <?php if(isset($place))echo $place; ?></h4>
<h4>Feelings : <?php if(isset($feelings))echo $feelings; ?></h4>

</main>