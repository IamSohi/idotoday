<div>
<?php echo form_open_multipart('user/profile/uploadpic','id="picform"'); ?>

<label for='fileinput'>
<img src='<?php echo base_url();?>uploads/<?php echo $imageName.'?'.time();?>' id='preview'>
<div id='previewa'>
</div>
</label>
<input id='fileinput' name='profilePic'  type='file'/>




</form>


<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/3.51/jquery.form.js"></script> 
<script >
$(document).ready(function() {
$(document).on('change', '#fileinput', function(){
// $("#preview").html('');
// $("#preview").html('<img src="loader.gif" alt="Uploading...."/>'); //download load loading image 

// $("#picform").submit();
$('#preview').hide();
$("#picform").ajaxForm({
    target:'#previewa'
}).submit();
});
});


// $("#picform").submit(function(){
//     //  $('#preview').attr('src',<?php echo base_url();?><?php echo 'uploads/';?><?php echo $imageName;?>);
//     $('#preview').hide();
// });


//     // location.reload();
//     // $('#preview').load('<?php echo base_url();?>uploads/<?php echo $imageName;?>'+' #preview')

//     // $('#preview').attr('src',<?php echo base_url();?><?php echo 'uploads/';?><?php echo $imageName;?>);
// d = new Date();
// var rc=<?php echo base_url();?><?php echo 'uploads/';?><?php echo $imageName.'?';?>;
// var cr=rc.__toString();
// var nm=cr+d.getTime();
// $("#preview").attr("src",cr);


</script>

</div>