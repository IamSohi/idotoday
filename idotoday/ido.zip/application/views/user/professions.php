<main title='professions'>

<?php
if(isset($result)){
   foreach($result as $item):?>

   <h3>Profession : <?php if(isset($item['profession']))echo $item['profession'];?></h3>
<h2>Description : <?php if(isset($item['description'])){echo $item['description'];}else{echo 'No';}?></h2>
   <h4>Place Of Work : <?php if(isset($item['work_place']))echo $item['work_place'];?></h4>
   <h4>PriceTag : <?php if(isset($item['amount_charge']))echo $item['amount_charge'].' ';if(isset($item['charge_scale']))echo $item['charge_scale'].' ';if(isset($item['currency']))echo $item['currency'];?></h4>
   <br/>
   <br/>
   <br/>
   


<?php endforeach;}else{
    echo '<h2>No Profession</h2>';

}
?>


</main>