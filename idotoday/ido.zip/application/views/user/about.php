<main>

<h3>My Passion : <?php if(isset($passion))echo $passion; ?> </h3>
<h3>MY Purpose : <?php if(isset($purpose))echo $purpose; ?></h3>
<h3>My Lifegoals : <?php if(isset($lifegoals))echo $lifegoals; ?></h3>
<?php if(isset($dob)){echo'<h3>Date of Birth : '.$dob.'</h3>';}?>
<?php  if(isset($country_code) && isset($phone_number)){echo '<h3>Phone Number : '.$country_code.' '.$phone_number.'</h3>';}?>
<?php  if(isset($city)){echo '<h3>City : '.$city.'</h3>';}?>


<main>