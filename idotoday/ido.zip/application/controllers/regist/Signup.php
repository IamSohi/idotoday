<?php

class Signup extends CI_Controller{



     function __construct(){
        parent::__construct();
        
         $this->load->helper('form'); 
         $this->load->helper('url');
         
        $this->load->database();
        
       
        $this->load->library('email');
        $this->load->model('Signup_Model');
        $this->load->library('session');
        $this->load->library('form_validation');



    }

    public function index(){

        $this->load->view('layout/header');
        $this->load->view('headers/signupHeader');
        $this->load->view('forms/signupform');
        $this->load->view('layout/footer');

    }

    public function signitup(){


        $config=array(
            array(
                'field'=>'firstname',
                'label'=>'Firstname',
                'rules'=>'required|min_length[2]|max_length[15]|regex_match[/^[a-zA-Z ]*$/]',
                'errors'=>'%s too Short'
           
            ),
            array(
                'field'=>'lastname',
                'label'=>'Lastname',
                'rules'=>'required|min_length[2]|max_length[15]|regex_match[/^[a-zA-Z ]*$/]',
                'errors'=>'%s too short'


            ),
            array(
                'field'=>'email',
                'label'=>'Email',
                'rules'=>'required|valid_email|is_unique[users.email]',
                'errors'=>'%s unvalid'

            ),
            array(
                'field'=>'pwd',
                'label'=>'Password',
                'rules'=>'required|trim|min_length[8]|max_length[15]|regex_match[/^.*(?=.{8,})(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).*$/]',
                'errors'=>'%s must be at least 8 characters and must contain at least one lower case letter, one upper case letter and one digit'
            ),
            array(
                'field'=>'gender',
                'label'=>'Gender',
                'rules'=>'required'

            )
        );
        
        $this->form_validation->set_rules($config);

        if ($this->form_validation->run() == FALSE){

            self::index();
                    
        }else{
            $gender;
            if($this->input->post('gender')=='male'){
                $gender=1;
            }else if($this->input->post('gender')=='female'){
                $gender=2;
            }else{
                $gender=3;
            }
                    
                        
                        $data=array(
                            'firstName'=>$this->input->post('firstname'),
                            'lastName'=>$this->input->post('lastname'),
                            'email'=>$this->input->post('email'),
                            'pwd'=>password_hash($this->input->post('pwd'), PASSWORD_BCRYPT),
                            'gender'=>$gender,
                            'hash'=>md5(rand(0, 1000))
                        );

                        if($id=$this->Signup_Model->insert($data)){
                            $data['id']=$id;
                            $_SESSION['email']=$data['email'];
                            $_SESSION['logged_in']=TRUE;
                            $_SESSION['uid']=$id;

                            if($this->Signup_Model->sendEmail($data)){
                                $this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Successfully registered. Please confirm the mail that has been sent to your email. </div>');

                                redirect('user/profile');

                            }else{
                                $this->session->set_flashdata('msg', '<div class="alert alert-danger text-center">Failed!! Please check your email and try again.</div>');
                                redirect('user/profile');
                            
                        }
                        
                }else{
                                $this->session->set_flashdata('msg', '<div class="alert alert-danger text-center">error in inserting your data</div>');
                                
                                
                                self::index();

                        }
        }


        





    }

    function confirmEmail($id,$hashcode){
        $result = $this->Signup_Model->get_hash_value($id);
        if($result){
            if($result->verified==0 && $result->hash==$hashcode){
                $this->Signup_Model->verifyEmail($id);
                $this->session->set_flashdata('verify', '<div class="alert alert-success text-center">Email address is confirmed. Please login to the system</div>');
                redirect('regist/login/index');


            }else{
                $this->session->set_flashdata('verify', '<div class="alert alert-success text-center">Email address is already confirmed. Please login to the system</div>');
                redirect('regist/login/index');

            }
        }else{
            $this->session->set_flashdata('verify', '<div class="alert alert-danger text-center">Email address is not confirmed. Please check your email and try again.</div>');
            redirect('regist/login/index');
        }
    }
}