<?php

class Login extends CI_Controller{

    function __construct(){
        parent::__construct();
        
         $this->load->helper('form'); 
         $this->load->helper('url');
         $this->load->database();
         $this->load->model('Login_Model');
        $this->load->library('session');
        $this->load->library('form_validation');




    }

    public function index(){


        $this->load->view('layout/header');
        $this->load->view('headers/LoginHeader');
        $this->load->view('forms/loginform',$_SESSION);
        $this->load->view('layout/footer');

    }

    public function logitin(){

        $config=array(
            array(
                'field'=>'email',
                'label'=>'Email',
                'rules'=>'required|valid_email',
                'errors'=>'%s unvalid'

            ),
            array(
                'field'=>'pwd',
                'label'=>'Password',
                'rules'=>'required|trim|min_length[8]|max_length[15]'
            )

            

        );
        $this->form_validation->set_rules($config);

        if ($this->form_validation->run() == FALSE){

            self::index();
                    

        // $this->load->view('layout/header');
        // $this->load->view('headers/signupHeader');
        // $this->load->view('forms/signupform');
        // $this->load->view('layout/footer');
        // echo 'Signp';

        }else if($query=$this->Login_Model->getUserRow($this->input->post('email'))){
            

            // $result=$query->row_array();

            if(password_verify($this->input->post('pwd'), $query->pwd)){
                $_SESSION['email']=$this->input->post('email');
                $_SESSION['logged_in']=TRUE;
                $_SESSION['uid']=$query->user_id;
                redirect('user/profile');

            } else{

                $this->session->set_flashdata('login_msg', '<div class="alert alert-success text-center">Wrong Password</div>');
                self::index();

            }
            }else{
                $this->session->set_flashdata('login_msg', '<div class="alert alert-success text-center">email does not exist</div>');
                self::index();
                }

    }

    //useless
    function email_exists($email){

        

        if($this->db->get_where('users',array('email'=>$this->input->post('email')))){
            return TRUE;

        }else{
            $this->form_validation->set_message('email', 'This email does not exists.');
                        return FALSE;
        }

    }
}