<?php

class Requests extends CI_Controller{

    function __construct(){
        parent::__construct();

        $this->load->library('session');
        $this->load->helper('url');
        $this->load->helper('form'); 
        $this->load->database();
        $this->load->model('Profile_Model');
        $this->load->library('form_validation');
    }

    public function index(){

        if($_SESSION['logged_in']){
        $this->load->view('layout/header');
        $this->load->view('headers/mainHeader');
        $this->load->view('forms/requestsForm');
        $this->load->view('layout/footer');

        }else{
                redirect('regist/login/index');
        }
    }

}


?>