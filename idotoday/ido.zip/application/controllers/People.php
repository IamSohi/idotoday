<?php

class People extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->helper('form'); 
        $this->load->database();
        $this->load->model('People_Model');
        $this->load->model('Profile_Model');
        $this->load->library('form_validation');

        
    }

    public function index(){

        // print_r($this->People_Model->getUsers());


        $result['people']=$this->People_Model->getUsers();
        $friendList=$this->Profile_Model->getUserConnections($_SESSION['uid']);


        foreach ($result['people'] as $key=>$id) {
            if($id['user_id']===$_SESSION['uid']){
                // echo 'done';
                unset($result['people'][$key]);
                // print_r($key);
            }
            if(isset($friendList) && in_array($id['user_id'],$friendList)){
                // echo 'done';
                unset($result['people'][$key]);
                // print_r($key);
        }else{
            continue;
        }

}

        // print_r($result['people']);
        $this->load->view('layout/header');
        $this->load->view('headers/mainHeader');
        $this->load->view('people',$result);
        $this->load->view('layout/footer');

    }

    public function person($id){
        $_SESSION['ouid']=$id;
        redirect('user/about/person');


    }

    public function connect($id){
        echo 'done';
        $uid=$_SESSION['uid'];
        if($id>$uid){
            
        $this->People_Model->connect($uid,$id);

        }else{
            
        $this->People_Model->connect($id,$uid);
        }
        // redirect('people');

    }

    public function unConnect($id){
        echo 'done';
        $uid=$_SESSION['uid'];
        if($id>$uid){
            
        $this->People_Model->unConnect($id);

        }else{
            
        $this->People_Model->unConnect($uid);
        }
        // redirect('people');

    }




}