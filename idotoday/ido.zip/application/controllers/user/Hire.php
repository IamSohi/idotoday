<?php

class Hire extends CI_Controller{

    function __construct(){
        parent::__construct();

    }

}

?>