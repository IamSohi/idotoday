<?php

class Requests extends CI_Controller{

    function __construct(){
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->helper('form'); 
        $this->load->database();
        $this->load->model('Profile_Model');
        $this->load->library('form_validation');

    }

    public function index(){
        if($_SESSION['logged_in']){

        $this->load->view('layout/header');
        $this->load->view('headers/mainHeader');
        
        $this->load->view('subHeaders/userSubHeader');
        
        $this->load->view('forms/requestsForm');


        $this->load->view('layout/footer');
        
        }else{
                redirect('regist/login/index');
        }
    }

    public function request(){

        $config=array(
            array(
                'field'=>'request',
                'Label'=>'Request',
                'rules'=>'required|min_length[2]|max_length[255]|regex_match[/^[a-zA-Z0-9._ -]*$/]',
            ),
            array(
                'field'=>'description',
                'Label'=>'Description',
                'rules'=>'min_length[10]|max_length[1000]|regex_match[/^[a-zA-Z0-9._\s,-]*$/]',
            ),
            array(
                'field'=>'toWhom',
                'Label'=>'toWhom',
                'rules'=>'required|min_length[2]|max_length[50]|regex_match[/^[a-zA-Z0-9._ -]*$/]',
            ),
            array(
                'field'=>'bounty',
                'Label'=>'Bounty',
                'rules'=>'',
            ),
            array(
                'field'=>'currency',
                'Label'=>'Currency',
                'rules'=>'',
            )
        );

        $this->form_validation->set_rules($config);

        if ($this->form_validation->run() == FALSE){

            self::index();
                    
        }else{

            $data=array(
                'user_id'=>$_SESSION['uid'],
                'request'=>$this->input->post('request'),
                'description'=>$this->input->post('description'),
                'to_who'=>$this->input->post('toWhom'),
                'bounty'=>$this->input->post('bounty'),
                'currency'=>$this->input->post('currency')


            );

            if($this->Profile_Model->insert_1('requests',$data)){

                echo 'updated';
                redirect('user/requests');

            }else{

            }

    }
}
}

?>