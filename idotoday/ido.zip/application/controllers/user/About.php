<?php

class About extends CI_Controller{

    function __construct(){
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->helper('form'); 
        $this->load->database();
        $this->load->model('Profile_Model');
        $this->load->library('form_validation');

    }

    public function index(){
        if($_SESSION['logged_in']){


        $this->load->view('layout/header');
        $this->load->view('headers/mainHeader');
        
        $this->load->view('subHeaders/userSubHeader');
        
        $this->load->view('forms/aboutForm',$this->Profile_Model->getAboutInfo($_SESSION['uid']));


        $this->load->view('layout/footer');
        
        }else{
                redirect('regist/login/index');
        }
    }


    public function person(){
        if($_SESSION['logged_in']){
        

        
        $this->load->view('layout/header');
        $this->load->view('headers/mainHeader');
        
        $this->load->view('subHeaders/otherUserSubHeader');
        
        $this->load->view('user/about',$this->Profile_Model->getAboutInfo($_SESSION['ouid']));


        $this->load->view('layout/footer');
        }else{
                redirect('regist/login/index');
        }

    }

    public function edit(){
        $config=array(
            array(
                'field'=>'passion',
                'Label'=>'Passion',
                'rules'=>'required|min_length[2]|max_length[210]|regex_match[/^[a-zA-Z0-9._ -]*$/]',
            ),
            array(
                'field'=>'purpose',
                'Label'=>'Purpose',
                'rules'=>'required|min_length[2]|max_length[210]|regex_match[/^[a-zA-Z0-9._ -]*$/]',
            ),
            array(
                'field'=>'lifegoals',
                'Label'=>'Believe',
                'rules'=>'required|min_length[2]|max_length[210]|regex_match[/^[a-zA-Z0-9._ -]*$/]',
            ),
            array(
                'field'=>'dob',
                'Label'=>'Date of birth',
                'rules'=>'',
            ),
            array(
                'field'=>'country_code',
                'Label'=>'Country Code',
                'rules'=>'min_length[1]|max_length[5]|regex_match[/^[+0-9-]*$/]',
            ),
            array(
                'field'=>'number',
                'Label'=>'number',
                'rules'=>'min_length[1]|max_length[15]|regex_match[/^[0-9-]*$/]',
            ),
            array(
                'field'=>'city',
                'Label'=>'City',
                'rules'=>'min_length[2]|max_length[50]|regex_match[/^[a-zA-Z0-9._ -]*$/]',
            ),
            
        );

        $this->form_validation->set_rules($config);

        if ($this->form_validation->run() == FALSE){

            self::index();
                    
        }else{

            //rough
            if($this->input->post('loveYourWork')){
                $loveWork=TRUE;
            }
            if($this->input->post('beleive')){
                $beleive=TRUE;
            }

            $data=array(
                'user_id'=>$_SESSION['uid'],
                'passion'=>$this->input->post('passion'),
                'purpose'=>$this->input->post('purpose'),
                'lifegoals'=>$this->input->post('lifegoals'),
                'dob'=>$this->input->post('dob'),
                'country_code'=>$this->input->post('country_code'),
                'phone_number'=>$this->input->post('number'),
                'city'=>$this->input->post('city')
            

            );


            if($this->Profile_Model->insert('about',$data,array('user_id ='=>$_SESSION['uid']))){
                
                redirect('user/about');

                
                

                        
                }else{
                        

            }

    }
}
}

?>