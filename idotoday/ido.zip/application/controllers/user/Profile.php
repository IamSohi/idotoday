<?php

class Profile extends CI_Controller{

    function __construct(){
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->helper('form'); 
        $this->load->database();
        $this->load->model('Profile_Model');
        $this->load->library('form_validation');

    }

    public function index(){
        if($_SESSION['logged_in']){


        $array=$this->Profile_Model->getProfileInfo($_SESSION['uid']);
        print_r($array);
        $this->load->view('layout/header');
        $this->load->view('headers/mainHeader');
        $this->load->view('user/profile',$this->Profile_Model->getImageName($_SESSION['uid']));
        $this->load->view('forms/userProfileForm',$this->Profile_Model->getProfileInfo($_SESSION['uid']));
        $this->load->view('layout/footer');
        
        }else{
                redirect('regist/login/index');
        }

    }

    public function uploadpic(){


        if(empty($_FILES['profilePic'])){
            return;
        }else{

        
        $path =base_url();
        // echo pathinfo($path.'uploads/'.$_FILES['profilePic']['name'],PATHINFO_EXTENSION);
        $config['upload_path']   = './uploads/'; 
         $config['allowed_types'] = 'gif|jpg|png'; 
         $config['max_size']      = 5000; 
         $config['max_width']     = 0; 
         $config['max_height']    = 0;
         $config['file_name']     = 'profilePic'.$_SESSION['uid'].'.'.pathinfo($path.'uploads/'.$_FILES['profilePic']['name'],PATHINFO_EXTENSION);
         $this->load->library('upload', $config);

         echo $path.'uploads/'.$config['file_name'];

         $data=array(
             'imageName'=> $config['file_name']
         );


         $this->Profile_Model->imageUpload($data,$_SESSION['uid']);



         if( file_exists('uploads/'.$config['file_name'])){
             unlink('uploads/'.$config['file_name']);

         }

         if ( ! $this->upload->do_upload('profilePic')) {
        $error = array('error' => $this->upload->display_errors()); 
        print $error['error'];
       }else{
        //    redirect('user/profile');

           echo '<img src='.base_url().'uploads/'.$config['file_name'].'?'.time().'>';
                       
       }
        }
			
        
        
    }

    public function edit(){

        $config=array(
            array(
                'field'=>'workStatus',
                'Label'=>'Work Status',
                'rules'=>'required|min_length[2]|max_length[210]',
            ),
            array(
                'field'=>'loveYourWork',
                'label'=>'Love Work',
                'rules'=>'required'
            ),
            array(
                'field'=>'passion',
                'Label'=>'Passion',
                'rules'=>'required|min_length[2]',
            ),
            array(
                'field'=>'purpose',
                'Label'=>'Purpose',
                'rules'=>'required|min_length[2]',
            ),
            array(
                'field'=>'beleive',
                'Label'=>'Believe',
                'rules'=>'required',
            ),
            array(
                'field'=>'profession',
                'Label'=>'Profession',
                'rules'=>'min_length[2]',
            ),
            array(
                'field'=>'workPlace',
                'Label'=>'Work Place',
                'rules'=>'min_length[2]|max_length[100]',
            ),
            array(
                'field'=>'dob',
                'Label'=>'Date of birth',
                'rules'=>'',
            ),
            array(
                'field'=>'city',
                'Label'=>'City',
                'rules'=>'min_length[2]|max_length[50]',
            ),
            array(
                'field'=>'number',
                'Label'=>'number',
                'rules'=>'',
            )
        );

        $this->form_validation->set_rules($config);

        if ($this->form_validation->run() == FALSE){

            self::index();
                    
        }else{

            //rough
            if($this->input->post('loveYourWork')){
                $loveWork=TRUE;
            }
            if($this->input->post('beleive')){
                $beleive=TRUE;
            }

            $data1=array(
                'workStatus'=>$this->input->post('workStatus'),
                'userId'=>$_SESSION['uid'],
                'loveWork'=>$this->input->post('loveYourWork'),
                'passion'=>$this->input->post('passion'),
                'purpose'=>$this->input->post('purpose'),
                'believeWork'=>$this->input->post('beleive'),
                'Profession'=>$this->input->post('profession'),
                'workPlace'=>$this->input->post('workPlace'),

            );

            $data2=array(
                'dob'=>$this->input->post('dob'),
                'city'=>$this->input->post('city'),
                'number'=>$this->input->post('number')

            );

            if($this->Profile_Model->insert('userProfile',$data1,array('userId ='=>$_SESSION['uid'])) && $this->Profile_Model->insert('users',$data2,array('id ='=>$_SESSION['uid']))){

        $this->load->view('layout/header');
        $this->load->view('headers/mainHeader');
        $this->load->view('user/profile');
        $this->load->view('forms/userProfileForm',$this->Profile_Model->getProfileInfo($_SESSION['uid']));
        $this->load->view('layout/footer');

                
                

                        
                }else{
                                
                                $this->session->set_flashdata('profile_msg', '<div class="alert alert-success text-center">error in inserting your data</div>');
                                self::index();

            }



        }

    }

}