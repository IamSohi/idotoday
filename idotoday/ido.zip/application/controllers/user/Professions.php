<?php

class Professions extends CI_Controller{

    function __construct(){
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->helper('form'); 
        $this->load->database();
        $this->load->model('Profile_Model');
        $this->load->library('form_validation');

    }

    public function index(){
        if($_SESSION['logged_in']){
            $result['result']=$this->Profile_Model->getUserProfessions($_SESSION['uid']);

            print_r($this->Profile_Model->getUserProfessions($_SESSION['uid']));

        $this->load->view('layout/header');
        $this->load->view('headers/mainHeader');
        
        $this->load->view('subHeaders/userSubHeader');
        $this->load->view('forms/professionsForm');
        $this->load->view('user/professions',$result);
        


        $this->load->view('layout/footer');
        
        }else{
                redirect('regist/login/index');
        }
    }

    public function person(){
        $result['result']=$this->Profile_Model->getUserProfessions($_SESSION['ouid']);

            print_r($this->Profile_Model->getUserProfessions($_SESSION['ouid']));

        $this->load->view('layout/header');
        $this->load->view('headers/mainHeader');
        
        $this->load->view('subHeaders/otherUserSubHeader');
        $this->load->view('user/professions',$result);
        

        $this->load->view('layout/footer');
        
    }

    public function add(){

        $config=array(
            array(
                'field'=>'profession',
                'Label'=>'Profession',
                'rules'=>'required|min_length[2]|max_length[100]|regex_match[/^[a-zA-Z0-9._ -]*$/]',
            ),
            array(
                'field'=>'description',
                'Label'=>'Description',
                'rules'=>'min_length[2]|max_length[500]|regex_match[/^[a-zA-Z0-9._\s,-]*$/]',
            ),
            array(
                'field'=>'workplace',
                'Label'=>'Place Of Work',
                'rules'=>'required|min_length[2]|max_length[50]|regex_match[/^[a-zA-Z0-9._ -]*$/]',
            ),
            array(
                'field'=>'price',
                'Label'=>'Amount Charged',
                'rules'=>'required|min_length[2]|max_length[100]|regex_match[/^[a-zA-Z0-9., -]*$/]',
            ),
            array(
                'field'=>'currency',
                'Label'=>'Currency',
                'rules'=>'',
            ),
            array(
                'field'=>'timescale',
                'Label'=>'',
                'rules'=>'',
            )
        );

        $this->form_validation->set_rules($config);

        if ($this->form_validation->run() == FALSE){

            self::index();
                    
        }else{

            if(is_numeric($this->input->post('price'))){
                $charge_scale=$this->input->post('timescale');
                $currency=$this->input->post('currency');
                

            }else{
                $charge_scale=null;
                $currency=null;
                

            }

            $data=array(
                'user_id'=>$_SESSION['uid'],
                'profession'=>$this->input->post('profession'),
                'description'=>$this->input->post('description'),
                'work_place'=>$this->input->post('workplace'),
                'amount_charge'=>$this->input->post('price'),
                'charge_scale'=>$charge_scale,
                'currency'=>$currency
            );
            
            if($this->Profile_Model->insert_1('professions',$data)){

                echo 'added';
                redirect('user/professions');
            }else{

            }


        }

    }
}

?>