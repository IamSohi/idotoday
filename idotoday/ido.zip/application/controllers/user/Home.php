<?php

class Home extends CI_Controller{

    function __construct(){
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');

    }

    public function index(){

        $this->load->view('layout/header');
        $this->load->view('headers/mainHeader');
        $this->load->view('message');
        $this->load->view('layout/footer');

    }
}