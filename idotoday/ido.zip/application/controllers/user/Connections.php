<?php

class Connections extends CI_Controller{

    function __construct(){
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->helper('form'); 
        $this->load->database();
        $this->load->model('Profile_Model');
        $this->load->library('form_validation');

    }

    public function index(){
        if($_SESSION['logged_in']){

            print_r($this->Profile_Model->getUserConnections_1($_SESSION['uid']));

            $array['people']=$this->Profile_Model->getUserConnections_1($_SESSION['uid']);

        $this->load->view('layout/header');
        $this->load->view('headers/mainHeader');
        
        $this->load->view('subHeaders/userSubHeader');
        
        $this->load->view('people',$array);
        


        $this->load->view('layout/footer');
        
        }else{
                redirect('regist/login/index');
        }
    }


    public function person(){

        
        $this->load->view('layout/header');
        $this->load->view('headers/mainHeader');
        
        $this->load->view('subHeaders/otherUserSubHeader');
        
        $this->load->view('layout/footer');


    }

    public function userConnections(){
        print_r($this->Profile_Model->getUserConnections($_SESSION['uid']));

    }
}

?>