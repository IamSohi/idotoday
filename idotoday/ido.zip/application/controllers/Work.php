<?php

class Work extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->helper('form'); 
        $this->load->database();
        $this->load->model('Work_Model');
        $this->load->library('form_validation');

        
    }

    public function index(){
        $this->load->view('layout/header');
        $this->load->view('headers/mainHeader');
        $this->load->view('work');
        $this->load->view('layout/footer');

    }
}