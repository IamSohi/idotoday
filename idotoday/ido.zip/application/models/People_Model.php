<?php

class People_Model extends CI_Model{

    function __construct(){
        parent::__construct();

    }
    
    public function getUsers(){
        return $this->db->select('user_id')->get('users')->result_array();

    }

    public function connect($id,$uid){

        $data=array('user_id'=>$uid,'friend_id'=>$id);

        if($this->db->insert('connections',$data)){
        // $insert_id = $this->db->insert_id();
    
        return TRUE;      
        }else{
            return FALSE;
        }
    }

    public function unConnect($id){

        $data=array('user_id'=>$id);

        if($this->db->delete('connections',$data)){
        // $insert_id = $this->db->insert_id();
    
        return TRUE;      
        }else{
            return FALSE;
        }
    }


}