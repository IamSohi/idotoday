<?php

class Profile_Model extends CI_Model{

    function __construct(){
        parent::__construct();

    }

    public function insert($table,$data,$array){
        $this->db->set($data);
        $this->db->where($array);
        if($this->db->update($table)){
        // if($this->db->query("'INSERT INTO '.$table.' (city'"){
        // $insert_id = $this->db->insert_id();
        // return  $insert_id;  
        return TRUE;      
        }else{
            return FALSE;
        }
    }
    public function insert_1($table,$data){
        if($this->db->insert($table,$data)){
        // $insert_id = $this->db->insert_id();
    
        return TRUE;      
        }else{
            return FALSE;
        }
    }

    public function imageUpload($data,$id){
        $this->db->set($data);
        $this->db->where('user_id',$id);
        if($this->db->update('profilepics')){
            return True;
        }else{
            return FALSE;
        }

    }

    public function getImageName($id){
        $this->db->select('imageName');
        return $array1= $this->db->get_where('profilepics', array('user_id' => $id))->row_array();
    }

    public function getProfileInfo($id){

        // $this->db->select('dob,city,number');
        // $array1= $this->db->get_where('users', array('id' => $id))->row_array();

        return $this->db->get_where('about', array('user_id' => $id))->row_array();

        // return array_merge($array1,$array2);
        // return $array;

    }

    public function getAboutInfo($id){

        // $this->db->select('dob,city,number');
        if($this->db->get_where('about', array('user_id' => $id))->row_array()){
            return $this->db->get_where('about', array('user_id' => $id))->row_array();
        }else{
            return;
        }

        // $array2= $this->db->get_where('userprofile', array('userId' => $id))->row_array();

        // return array_merge($array1,$array2);
        // return $array;

    }

    public function getUserProfessions($user_id){

        if($this->db->get_where('professions', array('user_id' => $user_id))->result()){
            return $this->db->get_where('professions', array('user_id' => $user_id))->result_array();
        }else{
            return;
        }



    }

    public function getUserConnections($user_id){

        

        if($this->db->get_where('connections', array('user_id' => $user_id))->result() ){
            $this->db->select('friend_id');
            $array1= $this->db->get_where('connections', array('user_id' => $user_id))->result_array();
            $array_1=array();

            foreach($array1 as $row){
                $array_1[]=$row['friend_id'];

            }


            $this->db->select('user_id');
            $array2= $this->db->get_where('connections', array('friend_id' => $user_id))->result_array();
            $array_2=array();
            foreach($array2 as $row){
                $array_2[]=$row['user_id'];

            }

            return array_merge($array_1,$array_2);
        }else{
            return;
        }

    }

    public function getUserConnections_1($user_id){

        

        if($this->db->get_where('connections', array('user_id' => $user_id))->result() ){
            $this->db->select('friend_id');
            $array1= $this->db->get_where('connections', array('user_id' => $user_id))->result_array();
            $array_1=array();

            foreach($array1 as $row){
                $array_1[]=array('user_id'=>$row['friend_id']);

            }


            $this->db->select('user_id');
            $array2= $this->db->get_where('connections', array('friend_id' => $user_id))->result_array();
            $array_2=array();
            foreach($array2 as $row){
                
                $array_2[]=array('user_id'=>$row['user_id']);

            }

            return array_merge($array_1,$array_2);
        }else{
            return;
        }

    }


    
}