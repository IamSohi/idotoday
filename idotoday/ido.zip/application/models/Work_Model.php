<?php

class Work_Model extends CI_Model{

    function __construct(){
        parent::__construct();

    }
    
    public function insertStatus($data,$array){
        $this->db->set($data);
        $this->db->where($array);
        if($this->db->update('work')){
            return TRUE;
        }else{
            return FALSE;
        }

    }

    public function insert($table,$data){
        if($this->db->insert($table,$data)){
        // $insert_id = $this->db->insert_id();
    
        return TRUE;      
        }else{
            return FALSE;
        }
    }

    public function getUsers(){
        return $this->db->select('id')->get('users')->result_array();

    }

    public function getUserWorkStatus($id){
        return $this->db->get_where('work', array('user_id' => $id))->row_array();
    }

}