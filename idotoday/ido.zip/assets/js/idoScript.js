

$(document).ready(function() {
$(document).on('change', '#fileinput', function(){
$('#preview').hide();
$("#picform").ajaxForm({
    target:'#previewa'
}).submit();
});
});

function connect(id){
    // $(".hh").html("UnConnect");

       $.ajax({
url: "people/connect/"+id,

});

$('#connect'+id).hide();
$('#unconnect'+id).show();
}

function unConnect(id){
    // $(".hh").html("UnConnect");

       $.ajax({
url: "people/unConnect/"+id,

});

$('#connect'+id).show();
$('#unconnect'+id).hide();
}




// $(document).ready(

//     function connect(uid,urll){
        

//         // var uid=$(this).getAttribute("id");

//         // $.ajax({
//         //     url:'/index.php/people/connect/1000007'
            
//         // });

//     //     $.post("/people/connect/1000007",null, function (data) {  
//     //        alert(data);  
//     //    });

//        $.ajax({
// async: false,
// cache: false,
// type: "POST",
// url: "@(Url.Action('people', 'connect'))",
// data: { 'id':'1000007'},
// success: function (data) {
// }
// });

        
//         $(".hh").html("UnConnect");

        

//     }




// );
